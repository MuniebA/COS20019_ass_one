<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>get file</title>
</head>
<body>
    

<style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .image {
            max-width: 100%;
            max-height: 100%;
        }
    </style>



<img src="images.jpg" alt="Cloud computing" class="image">


</body>
</html>